
import React, { useState, useEffect } from 'react';
import { HackathonIdea } from '../types';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { getRelatedIdeas } from '../services/geminiService';

interface IdeaCardProps {
  idea: HackathonIdea;
}

interface Collaborator {
  id: string;
  email: string;
  role: 'Viewer' | 'Editor';
  status: 'Pending' | 'Accepted';
  avatarColor: string;
}

export const IdeaCard: React.FC<IdeaCardProps> = ({ idea }) => {
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isCollabModalOpen, setIsCollabModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [relatedIdeas, setRelatedIdeas] = useState<Partial<HackathonIdea>[]>([]);
  const [loadingRelated, setLoadingRelated] = useState(false);
  
  // Collaboration State
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<'Viewer' | 'Editor'>('Viewer');
  const [inviteSent, setInviteSent] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [collaborators, setCollaborators] = useState<Collaborator[]>([
    { id: '1', email: 'alex.dev@forge.ai', role: 'Editor', status: 'Accepted', avatarColor: 'bg-indigo-500' },
    { id: '2', email: 'sarah.m@hack.io', role: 'Viewer', status: 'Pending', avatarColor: 'bg-emerald-500' },
  ]);

  // Simple local storage simulation for saving ideas
  useEffect(() => {
    const savedIdeas = JSON.parse(localStorage.getItem('saved_ideas') || '[]');
    const exists = savedIdeas.some((item: any) => item.title === idea.title);
    setIsSaved(exists);
  }, [idea.title]);

  // Fetch related ideas
  useEffect(() => {
    const fetchRelated = async () => {
      setLoadingRelated(true);
      try {
        const related = await getRelatedIdeas(idea);
        setRelatedIdeas(related);
      } catch (err) {
        console.error("Failed to load related ideas", err);
      } finally {
        setLoadingRelated(false);
      }
    };
    fetchRelated();
  }, [idea]);

  const handleSave = () => {
    const savedIdeas = JSON.parse(localStorage.getItem('saved_ideas') || '[]');
    if (isSaved) {
      const filtered = savedIdeas.filter((item: any) => item.title !== idea.title);
      localStorage.setItem('saved_ideas', JSON.stringify(filtered));
      setIsSaved(false);
    } else {
      savedIdeas.push(idea);
      localStorage.setItem('saved_ideas', JSON.stringify(savedIdeas));
      setIsSaved(true);
    }
  };

  const chartData = [
    { subject: 'Novelty', A: idea.noveltyScore * 10, fullMark: 100 },
    { subject: 'Impact', A: idea.impactScore * 10, fullMark: 100 },
    { subject: 'Feasibility', A: idea.feasibilityScore * 10, fullMark: 100 },
    { subject: 'Tech Depth', A: 85, fullMark: 100 },
    { subject: 'UI/UX', A: 75, fullMark: 100 },
  ];

  const shareUrl = window.location.href;
  const teamLink = `${window.location.origin}/collab/${btoa(idea.title).slice(0, 12)}`;
  const shareText = `Check out this AI-generated hackathon idea: ${idea.title} on IdeaForge!`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const copyTeamLink = () => {
    navigator.clipboard.writeText(teamLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleSendInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    
    const newCollab: Collaborator = {
      id: Date.now().toString(),
      email: inviteEmail,
      role: inviteRole,
      status: 'Pending',
      avatarColor: ['bg-rose-500', 'bg-amber-500', 'bg-sky-500', 'bg-violet-500'][Math.floor(Math.random() * 4)]
    };

    setCollaborators(prev => [...prev, newCollab]);
    setInviteSent(true);
    setTimeout(() => {
      setInviteSent(false);
      setInviteEmail('');
    }, 3000);
  };

  const socialPlatforms = [
    {
      name: 'X',
      icon: (
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
        </svg>
      ),
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      color: 'hover:bg-slate-800'
    },
    {
      name: 'LinkedIn',
      icon: (
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
        </svg>
      ),
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
      color: 'hover:bg-blue-600'
    },
    {
      name: 'WhatsApp',
      icon: (
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
      ),
      url: `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`,
      color: 'hover:bg-green-600'
    }
  ];

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass p-8 rounded-3xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-6 flex gap-2">
              <button 
                onClick={() => setIsCollabModalOpen(true)}
                className="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-xl text-xs font-bold border border-white/10 transition-all flex items-center gap-2"
              >
                <span>COLLAB</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
              </button>
              <button 
                onClick={handleSave}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 ${
                  isSaved 
                  ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400' 
                  : 'bg-white/5 border-white/10 text-white hover:bg-white/10'
                }`}
              >
                <span>{isSaved ? 'SAVED' : 'SAVE'}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className={`h-3 w-3 ${isSaved ? 'fill-current' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                </svg>
              </button>
              <button 
                onClick={() => setIsShareModalOpen(true)}
                className="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-xl text-xs font-bold border border-white/10 transition-all flex items-center gap-2"
              >
                <span>SHARE</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
              </button>
              <div className="bg-indigo-600/20 text-indigo-400 px-4 py-2 rounded-xl text-xs font-bold border border-indigo-500/30">
                WINNER POTENTIAL
              </div>
            </div>
            
            <div className="mt-8 md:mt-0">
              <h2 className="text-4xl font-black mb-6 bg-gradient-to-r from-white via-white to-slate-500 bg-clip-text text-transparent">
                {idea.title}
              </h2>
              <div className="flex items-center gap-3 mb-6">
                <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-2 py-1 rounded tracking-[0.2em] uppercase">Primary Solution</span>
                <div className="h-px flex-grow bg-slate-800"></div>
              </div>
              <p className="text-slate-300 text-xl leading-relaxed mb-8 font-medium">
                {idea.description}
              </p>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-slate-900/40 p-6 rounded-2xl border border-white/5">
                  <h3 className="text-indigo-400 font-bold text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                    <span className="w-1 h-3 bg-indigo-500 rounded-full" />
                    The Problem
                  </h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{idea.problemStatement}</p>
                </div>
                <div className="bg-slate-900/40 p-6 rounded-2xl border border-white/5">
                  <h3 className="text-emerald-400 font-bold text-xs uppercase tracking-widest mb-3 flex items-center gap-2">
                    <span className="w-1 h-3 bg-emerald-500 rounded-full" />
                    Our Solution
                  </h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{idea.solution}</p>
                </div>
              </div>

              <div className="mt-8">
                 <h3 className="text-slate-500 font-bold text-xs uppercase tracking-widest mb-4">Implementation Stack</h3>
                 <div className="flex flex-wrap gap-2">
                   {idea.techStack.map(tech => (
                     <span key={tech} className="bg-slate-800/80 border border-slate-700 text-slate-300 px-4 py-1.5 rounded-full text-xs font-semibold hover:border-indigo-500 transition-colors cursor-default">
                       {tech}
                     </span>
                   ))}
                 </div>
              </div>
            </div>
          </div>

          <div className="glass p-8 rounded-3xl">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-white flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                </div>
                Execution Roadmap
              </h3>
              <span className="text-xs text-slate-500 font-mono">EST. WORKLOAD: {idea.roadmap.reduce((acc, p) => acc + p.tasks.length, 0)} SUBTASKS</span>
            </div>
            <div className="space-y-10">
              {idea.roadmap.map((phase, idx) => (
                <div key={idx} className="relative pl-10 border-l border-slate-800">
                  <div className="absolute -left-2.5 top-0 w-5 h-5 bg-indigo-500 rounded-full border-4 border-slate-900 shadow-[0_0_15px_rgba(99,102,241,0.5)]" />
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h4 className="font-bold text-white text-lg">{phase.name}</h4>
                      <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Phase {idx + 1}</p>
                    </div>
                    <span className="text-[10px] font-black bg-indigo-500/10 border border-indigo-500/20 px-3 py-1 rounded-full text-indigo-400">
                      {phase.duration}
                    </span>
                  </div>
                  <div className="grid gap-3">
                    {phase.tasks.map((task, tIdx) => (
                      <div key={tIdx} className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/5 flex items-center justify-between group hover:border-indigo-500/30 transition-all">
                        <div className="flex items-center gap-4">
                           <div className="w-2 h-2 rounded-full bg-slate-700 group-hover:bg-indigo-400 transition-colors" />
                           <span className="text-sm text-slate-300 font-medium">{task.task}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          {task.dependencies.length > 0 && (
                            <div className="hidden sm:flex -space-x-1">
                              {task.dependencies.slice(0, 2).map((_, i) => (
                                <div key={i} className="w-4 h-4 rounded-full bg-indigo-900 border border-slate-900" title="Dependency" />
                              ))}
                            </div>
                          )}
                          <span className="text-[10px] text-slate-500 font-mono bg-black/30 px-2 py-0.5 rounded uppercase">{task.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Related Ideas Section */}
          <div className="glass p-8 rounded-3xl space-y-8">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-white flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/20 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </div>
                Related Concepts
              </h3>
              {loadingRelated && <div className="text-[10px] font-black text-indigo-400 animate-pulse tracking-widest uppercase">Analyzing...</div>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {loadingRelated ? (
                [1, 2, 3].map(i => (
                  <div key={i} className="bg-white/5 border border-white/5 p-6 rounded-2xl animate-pulse space-y-4">
                    <div className="h-4 bg-slate-800 rounded w-3/4" />
                    <div className="space-y-2">
                      <div className="h-2.5 bg-slate-800 rounded w-full" />
                      <div className="h-2.5 bg-slate-800 rounded w-5/6" />
                    </div>
                    <div className="flex gap-2 pt-2">
                      <div className="h-4 bg-slate-800 rounded-full w-12" />
                      <div className="h-4 bg-slate-800 rounded-full w-12" />
                    </div>
                  </div>
                ))
              ) : relatedIdeas.length > 0 ? (
                relatedIdeas.map((rel, idx) => (
                  <div key={idx} className="bg-white/5 border border-white/5 hover:border-indigo-500/30 p-6 rounded-2xl transition-all group flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm mb-2 group-hover:text-indigo-400 transition-colors line-clamp-1">{rel.title}</h4>
                      <p className="text-[10px] text-slate-400 line-clamp-3 leading-relaxed">{rel.description}</p>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-1">
                      {rel.techStack?.slice(0, 2).map(t => (
                        <span key={t} className="text-[8px] bg-indigo-500/10 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-500/20 uppercase font-black">{t}</span>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full py-8 text-center text-slate-500 italic text-sm">
                  No similar concepts identified for this niche.
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass p-8 rounded-3xl flex flex-col items-center border border-indigo-500/10">
            <h3 className="text-lg font-bold mb-8 text-center text-white uppercase tracking-widest text-xs">Winning Strategy Profile</h3>
            <div className="w-full h-72">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={chartData}>
                  <PolarGrid stroke="#1e293b" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 11, fontWeights: 'bold' }} />
                  <Radar
                    name="Idea"
                    dataKey="A"
                    stroke="#6366f1"
                    strokeWidth={2}
                    fill="#6366f1"
                    fillOpacity={0.4}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 p-6 bg-gradient-to-br from-indigo-600/10 to-transparent border border-indigo-500/20 rounded-2xl w-full">
              <div className="flex items-center gap-2 mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-indigo-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" />
                </svg>
                <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em]">Judge Predictor AI</h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed italic">
                "{idea.winningStrategy}"
              </p>
            </div>
          </div>

          <div className="glass p-8 rounded-3xl space-y-4">
            <h3 className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-2">Quick Deployment</h3>
            <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-2xl transition-all shadow-xl shadow-indigo-600/20 flex items-center justify-center gap-3">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>
              Spin up Boilerplate
            </button>
            <button 
              onClick={() => setIsCollabModalOpen(true)}
              className="w-full border border-slate-800 hover:border-slate-600 bg-slate-900/50 text-white py-3 rounded-2xl transition-all flex items-center justify-center gap-2 text-sm font-semibold"
            >
              Invite Co-founders
            </button>
            <button className="w-full border border-slate-800 hover:border-slate-600 bg-slate-900/50 text-white py-3 rounded-2xl transition-all flex items-center justify-center gap-2 text-sm font-semibold">
              Export JSON Config
            </button>
          </div>
        </div>
      </div>

      {/* Share Modal Overlay */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setIsShareModalOpen(false)}
          />
          <div className="glass relative w-full max-w-md p-8 rounded-[2rem] border border-white/10 animate-in zoom-in-95 duration-300">
            <button 
              onClick={() => setIsShareModalOpen(false)}
              className="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>

            <h3 className="text-2xl font-black text-white mb-2">Share Idea</h3>
            <p className="text-slate-400 text-sm mb-8 font-medium">Spread the inspiration across your network.</p>

            <div className="flex justify-between gap-4 mb-10">
              {socialPlatforms.map((platform) => (
                <a
                  key={platform.name}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex flex-col items-center gap-3 flex-1 p-4 rounded-2xl bg-white/5 border border-white/5 transition-all ${platform.color} group`}
                >
                  <div className="text-slate-300 group-hover:text-white transition-colors">
                    {platform.icon}
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 group-hover:text-white transition-colors">{platform.name}</span>
                </a>
              ))}
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Or Copy Link</label>
              <div className="flex gap-2 p-2 bg-slate-900/50 border border-slate-800 rounded-2xl">
                <input 
                  type="text" 
                  readOnly 
                  value={shareUrl}
                  className="flex-grow bg-transparent px-4 py-2 text-xs text-slate-300 focus:outline-none"
                />
                <button 
                  onClick={copyToClipboard}
                  className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${
                    copied ? 'bg-emerald-600 text-white' : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/20'
                  }`}
                >
                  {copied ? 'COPIED' : 'COPY'}
                </button>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.1em]">© 2025 IdeaForge AI • Belongs to Devcircle</p>
            </div>
          </div>
        </div>
      )}

      {/* Collaborate Modal Overlay */}
      {isCollabModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setIsCollabModalOpen(false)}
          />
          <div className="glass relative w-full max-w-xl p-8 md:p-10 rounded-[2.5rem] border border-white/10 animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh] overflow-hidden">
            <button 
              onClick={() => setIsCollabModalOpen(false)}
              className="absolute top-8 right-8 text-slate-400 hover:text-white transition-colors z-10"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>

            <div className="mb-8">
              <h3 className="text-3xl font-black text-white mb-2">Team Collaboration</h3>
              <p className="text-slate-400 text-sm font-medium">Invite teammates to build this project together.</p>
            </div>

            <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar space-y-8">
              {/* Invite Form */}
              <form onSubmit={handleSendInvite} className="space-y-4 bg-white/5 p-6 rounded-3xl border border-white/5">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="md:col-span-3 space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Email Address</label>
                    <input 
                      type="email" 
                      placeholder="teammate@example.com"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Role</label>
                    <select 
                      value={inviteRole}
                      onChange={(e) => setInviteRole(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-4 py-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/40 appearance-none font-bold"
                    >
                      <option>Viewer</option>
                      <option>Editor</option>
                    </select>
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={inviteSent || !inviteEmail}
                  className={`w-full py-4 rounded-2xl font-black text-sm transition-all shadow-xl ${
                    inviteSent 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20 active:scale-95 disabled:opacity-50'
                  }`}
                >
                  {inviteSent ? 'INVITATION SENT!' : 'SEND TEAM INVITE'}
                </button>
              </form>

              {/* Team Members List */}
              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Team Members</h4>
                <div className="space-y-3">
                  {collaborators.map((collab) => (
                    <div key={collab.id} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-white/10 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl ${collab.avatarColor} flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                          {collab.email.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white line-clamp-1">{collab.email}</p>
                          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{collab.role}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest border ${
                          collab.status === 'Accepted' 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' 
                          : 'bg-amber-500/10 text-amber-400 border-amber-500/20 animate-pulse'
                        }`}>
                          {collab.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Share Link Section */}
              <div className="pt-6 border-t border-white/5 space-y-4">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Direct Team Link</label>
                <div className="flex gap-2 p-2 bg-slate-900 border border-slate-800 rounded-2xl">
                  <input 
                    type="text" 
                    readOnly 
                    value={teamLink}
                    className="flex-grow bg-transparent px-4 py-2 text-xs text-slate-500 font-mono focus:outline-none"
                  />
                  <button 
                    onClick={copyTeamLink}
                    className={`px-6 py-2 rounded-xl text-xs font-bold transition-all ${
                      linkCopied ? 'bg-emerald-600 text-white' : 'bg-slate-800 hover:bg-slate-700 text-white border border-white/10'
                    }`}
                  >
                    {linkCopied ? 'COPIED' : 'COPY'}
                  </button>
                </div>
                <p className="text-[10px] text-slate-600 italic text-center">Anyone with this link can join the shared workspace.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
