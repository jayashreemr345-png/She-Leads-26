
import React, { useState, useEffect } from 'react';

interface Props {
  onLogin: () => void;
}

export const Login: React.FC<Props> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState('');
  const [passwordStrength, setPasswordStrength] = useState(0);

  // Calculate password strength
  useEffect(() => {
    if (isLogin) return;
    let strength = 0;
    if (password.length > 6) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;
    setPasswordStrength(strength);
  }, [password, isLogin]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Detailed security simulation
    const steps = [
      'Initializing Secure Tunnel...',
      'Generating RSA-4096 Key Pair...',
      'Performing Diffie-Hellman Exchange...',
      'Salting & Hashing Credentials...',
      'Encrypting Payload (AES-256-GCM)...',
      isLogin ? 'Verifying Vault Signature...' : 'Registering New Identity...',
      'Handshake Complete. Access Granted.'
    ];

    for (const step of steps) {
      setProcessStep(step);
      await new Promise(r => setTimeout(r, 400 + Math.random() * 400));
    }
    
    setIsProcessing(false);
    onLogin();
  };

  const handleSocialLogin = async (provider: 'Google' | 'GitHub') => {
    setIsProcessing(true);
    setProcessStep(`Redirecting to ${provider} Gateway...`);
    await new Promise(r => setTimeout(r, 800));
    setProcessStep(`Awaiting OAuth Callback from ${provider}...`);
    await new Promise(r => setTimeout(r, 1200));
    setProcessStep('Validating Social Identity Token...');
    await new Promise(r => setTimeout(r, 600));
    onLogin();
  };

  return (
    <div className="flex items-center justify-center min-h-[80vh] py-12 px-4">
      <div className="glass w-full max-w-md p-8 md:p-10 rounded-[3rem] border border-white/10 relative overflow-hidden shadow-2xl">
        {/* Security Pulse */}
        <div className="absolute top-6 left-6 flex items-center gap-2">
          <div className="relative">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping absolute inset-0" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 relative" />
          </div>
          <span className="text-[10px] font-black text-emerald-500/80 uppercase tracking-widest">Quantum-Secured</span>
        </div>

        {/* Processing Overlay */}
        {isProcessing && (
          <div className="absolute inset-0 z-50 bg-slate-950/95 backdrop-blur-2xl flex flex-col items-center justify-center p-10 text-center animate-in fade-in duration-500">
            <div className="w-20 h-20 relative mb-8">
              <div className="absolute inset-0 border-4 border-indigo-500/10 rounded-full" />
              <div className="absolute inset-0 border-t-4 border-indigo-500 rounded-full animate-spin" />
              <div className="absolute inset-2 border-r-4 border-emerald-500/40 rounded-full animate-spin-reverse" style={{ animationDuration: '3s' }} />
              <svg xmlns="http://www.w3.org/2000/svg" className="absolute inset-0 m-auto h-8 w-8 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <p className="text-white font-black text-sm uppercase tracking-[0.2em] mb-2">{processStep}</p>
            <div className="w-48 h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500 animate-progress" />
            </div>
          </div>
        )}

        <div className="text-center mb-10 pt-4">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-indigo-600/40 ring-4 ring-indigo-500/10 transition-transform hover:rotate-12">
            <span className="text-4xl font-bold text-white italic">F</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight mb-2">
            {isLogin ? 'Vault Access' : 'Forge Identity'}
          </h1>
          <p className="text-slate-500 text-[10px] uppercase tracking-[0.2em] font-black">
            {isLogin ? 'Secure Entry for Authorized Architects' : 'Register your engineering credentials'}
          </p>
        </div>

        <div className="space-y-6">
          {/* Social Logins */}
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => handleSocialLogin('Google')}
              className="flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 border border-white/5 py-4 rounded-2xl transition-all group active:scale-95"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Google</span>
            </button>
            <button 
              onClick={() => handleSocialLogin('GitHub')}
              className="flex items-center justify-center gap-3 bg-slate-900 hover:bg-slate-800 border border-white/5 py-4 rounded-2xl transition-all group active:scale-95"
            >
              <svg className="w-5 h-5" fill="white" viewBox="0 0 24 24">
                <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.11.82-.26.82-.577 0-.285-.011-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 21.795 24 17.31 24 12c0-6.63-5.37-12-12-12z" />
              </svg>
              <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">GitHub</span>
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/5"></div></div>
            <div className="relative flex justify-center text-[9px] font-black uppercase tracking-[0.4em] text-slate-600">
              <span className="bg-[#1e293b]/80 px-4 backdrop-blur-md">Terminal Auth</span>
            </div>
          </div>

          <form className="space-y-4" onSubmit={handleAuth}>
            {!isLogin && (
              <div className="space-y-1 animate-in slide-in-from-top-2 duration-300">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-2">Identity Signature</label>
                <input 
                  type="text" 
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all placeholder:text-slate-700 text-sm font-medium"
                  placeholder="Architect_01"
                />
              </div>
            )}
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-2">Secure Email</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all placeholder:text-slate-700 text-sm font-medium"
                placeholder="dev@forge.ai"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-2">Access Key</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/40 transition-all placeholder:text-slate-700 text-sm font-medium"
                placeholder="••••••••••••"
              />
              {!isLogin && password.length > 0 && (
                <div className="px-2 pt-2 space-y-1.5">
                   <div className="flex justify-between items-center text-[8px] font-black text-slate-500 uppercase tracking-widest">
                     <span>Entropy Level</span>
                     <span className={passwordStrength > 50 ? 'text-emerald-500' : 'text-amber-500'}>
                       {passwordStrength <= 25 ? 'WEAK' : passwordStrength <= 50 ? 'MODERATE' : passwordStrength <= 75 ? 'STRONG' : 'UNBREAKABLE'}
                     </span>
                   </div>
                   <div className="w-full h-1 bg-slate-800 rounded-full flex gap-1">
                      <div className={`h-full rounded-full transition-all duration-500 ${passwordStrength >= 25 ? (passwordStrength > 75 ? 'bg-emerald-500' : 'bg-indigo-500') : 'bg-rose-500 opacity-30'}`} style={{ width: '25%' }} />
                      <div className={`h-full rounded-full transition-all duration-500 ${passwordStrength >= 50 ? (passwordStrength > 75 ? 'bg-emerald-500' : 'bg-indigo-500') : 'bg-slate-800'}`} style={{ width: '25%' }} />
                      <div className={`h-full rounded-full transition-all duration-500 ${passwordStrength >= 75 ? (passwordStrength > 75 ? 'bg-emerald-500' : 'bg-indigo-500') : 'bg-slate-800'}`} style={{ width: '25%' }} />
                      <div className={`h-full rounded-full transition-all duration-500 ${passwordStrength >= 100 ? 'bg-emerald-500' : 'bg-slate-800'}`} style={{ width: '25%' }} />
                   </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider px-2 pt-2">
              <label className="flex items-center gap-2 text-slate-500 cursor-pointer hover:text-slate-400 transition-colors">
                <input type="checkbox" className="rounded-sm border-slate-800 bg-slate-900 text-indigo-600 focus:ring-0 w-3 h-3" /> 
                Auto-Reconnect
              </label>
              <button type="button" className="text-indigo-500 hover:text-indigo-400">Lost Key?</button>
            </div>

            <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-[1.5rem] transition-all shadow-2xl shadow-indigo-600/30 active:scale-[0.97] text-sm uppercase tracking-widest mt-4">
              {isLogin ? 'Initiate Session' : 'Register Blueprint'}
            </button>
          </form>

          <div className="text-center pt-2">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.1em]">
              {isLogin ? "IDENTITY NOT REGISTERED?" : "ALREADY IN THE SYSTEM?"}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-indigo-400 font-black ml-2 hover:text-indigo-300 transition-colors uppercase tracking-widest underline decoration-indigo-400/30 underline-offset-4"
              >
                {isLogin ? 'Forge Account' : 'Access Vault'}
              </button>
            </p>
          </div>
        </div>

        {/* Security Meta */}
        <div className="mt-12 pt-6 border-t border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-emerald-500" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            <span className="text-[8px] font-black text-slate-600 uppercase tracking-[0.2em]">End-to-End Encryption</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
            <span className="text-[8px] font-black text-slate-600 uppercase tracking-[0.2em]">Forge-Gate v2.4</span>
          </div>
        </div>
      </div>
      
      <style>{`
        @keyframes progress {
          0% { width: 0%; }
          50% { width: 70%; }
          100% { width: 100%; }
        }
        .animate-progress {
          animation: progress 5s linear infinite;
        }
        @keyframes spin-reverse {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
        .animate-spin-reverse {
          animation: spin-reverse 1s linear infinite;
        }
      `}</style>
    </div>
  );
};
