
import React from 'react';
import { Trend } from '../types';

interface Props {
  trends: Trend[];
  loading: boolean;
}

export const ExploreTrends: React.FC<Props> = ({ trends, loading }) => {
  return (
    <div className="space-y-12 py-12">
      <div className="max-w-3xl">
        <h1 className="text-5xl font-black text-white mb-6">Market <span className="text-indigo-500 italic">Pulse</span></h1>
        <p className="text-xl text-slate-400 leading-relaxed">
          Our specialized trend-engine monitors GitHub, Devpost, and news feeds to surface the most impactful technologies for your next hackathon project.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-64 glass rounded-3xl animate-pulse" />
          ))
        ) : (
          trends.map((trend, idx) => (
            <div key={idx} className="glass p-10 rounded-[2.5rem] hover:border-indigo-500/40 transition-all border border-white/5 relative group">
              <div className="absolute top-0 right-0 p-8">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600/10 flex items-center justify-center text-indigo-400 font-bold group-hover:scale-110 transition-transform">
                  {trend.relevance}%
                </div>
              </div>
              <span className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.3em] mb-4 block">
                SOURCE: {trend.source}
              </span>
              <h2 className="text-3xl font-bold text-white mb-4">{trend.topic}</h2>
              <p className="text-slate-400 leading-relaxed mb-8">
                {trend.description}
              </p>
              
              <div className="grid grid-cols-2 gap-6 pt-6 border-t border-white/5">
                <div>
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Market Gap</h4>
                  <p className="text-sm text-slate-300">High demand, low implementation</p>
                </div>
                <div>
                  <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Complexity</h4>
                  <p className="text-sm text-slate-300">Intermediate - Advanced</p>
                </div>
              </div>

              <button className="mt-8 text-indigo-400 font-bold text-sm flex items-center gap-2 hover:gap-4 transition-all">
                GENERATE IDEAS FOR THIS TREND
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
