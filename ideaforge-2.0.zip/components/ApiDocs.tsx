
import React from 'react';

export const ApiDocs: React.FC = () => {
  return (
    <div className="py-12 max-w-4xl mx-auto">
      <div className="mb-16">
        <h1 className="text-5xl font-black text-white mb-6">Engine <span className="text-slate-500">API</span></h1>
        <p className="text-xl text-slate-400 leading-relaxed">
          Integrate the IdeaForge 2.0 reasoning engine into your own hackathon platforms or internal tools.
        </p>
      </div>

      <div className="space-y-12">
        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <span className="text-indigo-500 font-mono">01.</span> Authentication
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            All requests must include your Bearer Token in the authorization header.
          </p>
          <div className="bg-black/40 rounded-2xl p-6 font-mono text-sm text-indigo-300 border border-white/5">
            Authorization: Bearer {'<YOUR_FORGE_TOKEN>'}
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <span className="text-indigo-500 font-mono">02.</span> Generate Idea
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Submit a POST request with user parameters to receive a structured project JSON.
          </p>
          <div className="bg-slate-900/80 rounded-2xl border border-white/5 overflow-hidden">
            <div className="px-6 py-2 bg-slate-800 border-b border-white/5 flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-400">POST /v2/forge/ideate</span>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">HTTPS</span>
            </div>
            <pre className="p-6 font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto">
{`{
  "profile": {
    "skills": ["React", "Rust", "Solidity"],
    "interests": ["FinTech", "Privacy"],
    "experience": "Intermediate",
    "time_limit": "48h"
  },
  "constraints": {
    "target_platform": "Mobile",
    "hardware_access": true
  }
}`}
            </pre>
          </div>
        </section>

        <div className="p-8 bg-indigo-600/10 border border-indigo-500/20 rounded-3xl">
          <h4 className="text-white font-bold mb-2">Developer Beta</h4>
          <p className="text-sm text-slate-400">
            The API is currently in closed beta. If you are a hackathon organizer, please contact us for priority access.
          </p>
        </div>
      </div>
    </div>
  );
};
