
import React from 'react';
import { View } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentView: View;
  setView: (view: View) => void;
  isLoggedIn: boolean;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentView, setView, isLoggedIn }) => {
  const navItems: { label: string; view: View }[] = [
    { label: 'Ideate', view: 'home' },
    { label: 'Explore Trends', view: 'trends' },
    { label: 'Success Stories', view: 'stories' },
    { label: 'API Docs', view: 'docs' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#0f172a] text-slate-200">
      <header className="py-4 px-6 md:px-12 glass sticky top-0 z-50 flex items-center justify-between border-b border-white/5">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => setView('home')}
        >
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
            <span className="text-2xl font-bold text-white italic">F</span>
          </div>
          <div className="hidden sm:block">
            <h1 className="text-xl font-bold tracking-tight text-white">IdeaForge <span className="text-indigo-400">2.0</span></h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-bold">The Innovation Engine</p>
          </div>
        </div>
        
        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.view}
              onClick={() => setView(item.view)}
              className={`text-sm font-semibold transition-all hover:text-indigo-400 ${
                currentView === item.view ? 'text-indigo-400' : 'text-slate-400'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setView('login')}
            className={`px-6 py-2 rounded-full text-sm font-bold transition-all ${
              isLoggedIn 
              ? 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700' 
              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/30'
            }`}
          >
            {isLoggedIn ? 'Account' : 'Sign In'}
          </button>
        </div>
      </header>

      <main className="flex-grow container mx-auto max-w-7xl px-4 py-8">
        {children}
      </main>

      <footer className="py-12 px-8 border-t border-slate-800/50 bg-[#0a0f1d]">
        <div className="container mx-auto max-w-7xl grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
             <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
                  <span className="text-xs font-bold text-white">F</span>
                </div>
                <span className="font-bold text-white">IdeaForge</span>
             </div>
             <p className="text-sm text-slate-500 leading-relaxed">
               Empowering engineers to build the next generation of multi-domain software, electronics, and mechanical systems with AI-driven insights.
             </p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Product</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><button onClick={() => setView('trends')} className="hover:text-indigo-400">Trending Tech</button></li>
              <li><button onClick={() => setView('home')} className="hover:text-indigo-400">Idea Generator</button></li>
              <li><button className="hover:text-indigo-400">Roadmap Engine</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Resources</h4>
            <ul className="space-y-2 text-sm text-slate-500">
              <li><button onClick={() => setView('docs')} className="hover:text-indigo-400">API Documentation</button></li>
              <li><button onClick={() => setView('stories')} className="hover:text-indigo-400">Success Stories</button></li>
              <li><button className="hover:text-indigo-400">Hackathon Guide</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">Connect</h4>
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-indigo-600 cursor-pointer transition-colors">𝕏</div>
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-indigo-600 cursor-pointer transition-colors">🐙</div>
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center hover:bg-indigo-600 cursor-pointer transition-colors">💬</div>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-slate-800 text-center text-slate-600 text-xs">
          © 2025 IdeaForge AI. Belongs to Devcircle. Powered by Gemini 3.
        </div>
      </footer>
    </div>
  );
};
