
import React from 'react';
import { Trend } from '../types';

interface TrendPanelProps {
  trends: Trend[];
  loading: boolean;
}

export const TrendPanel: React.FC<TrendPanelProps> = ({ trends, loading }) => {
  if (loading) {
    return (
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
        {[1, 2, 3].map((i) => (
          <div key={i} className="min-w-[280px] h-32 glass rounded-2xl animate-pulse p-4">
            <div className="w-24 h-4 bg-slate-700 rounded mb-2" />
            <div className="w-full h-8 bg-slate-700 rounded mb-4" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          Real-Time Market Intelligence
        </h2>
        <span className="text-xs text-slate-400">Updated hourly</span>
      </div>
      <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4">
        {trends.map((trend, idx) => (
          <div key={idx} className="min-w-[300px] glass p-5 rounded-2xl hover:border-indigo-500/50 transition-all group cursor-pointer">
            <div className="flex justify-between items-start mb-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">{trend.source}</span>
              <span className="text-xs bg-indigo-500/10 text-indigo-300 px-2 py-0.5 rounded-full">Score: {trend.relevance}</span>
            </div>
            <h3 className="font-bold text-slate-100 mb-2 group-hover:text-indigo-400 transition-colors">{trend.topic}</h3>
            <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{trend.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
