
import React from 'react';
import { SuccessStory } from '../types';

const STORIES: SuccessStory[] = [
  {
    id: '1',
    projectTitle: 'MedLink AI',
    hackathonName: 'HealthHacks 2024',
    award: '1st Place & Most Innovative',
    description: 'A real-time translation tool for medical professionals using Gemini Flash to bridge communication gaps in ER environments.',
  },
  {
    id: '2',
    projectTitle: 'EcoRoute',
    hackathonName: 'GreenCode Global',
    award: 'Best Sustainability Project',
    description: 'An AI-powered logistics optimizer that reduces carbon footprint by 15% using real-time traffic and weather data.',
  },
  {
    id: '3',
    projectTitle: 'ChainGuard',
    hackathonName: 'ETHGlobal London',
    award: 'Polygon Pool Prize Winner',
    description: 'Smart contract vulnerability scanner that uses deep learning to identify reentrancy attacks before deployment.',
  },
];

export const SuccessStories: React.FC = () => {
  return (
    <div className="py-12 space-y-16">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-black text-white">The <span className="text-indigo-500 underline decoration-indigo-500/30 underline-offset-8">Hall of Winners</span></h1>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg leading-relaxed">
          Projects forged here have gone on to win major hackathons, raise seed rounds, and solve real-world problems.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {STORIES.map((story) => (
          <div key={story.id} className="glass p-8 rounded-3xl flex flex-col hover:-translate-y-2 transition-transform duration-300 cursor-default group">
            <div className="mb-6 overflow-hidden rounded-2xl bg-indigo-900/20 aspect-video flex items-center justify-center text-slate-700 font-black text-2xl relative">
              <span className="opacity-10 group-hover:opacity-20 transition-opacity">IDEA FORGE 2.0</span>
              <div className="absolute bottom-4 left-4 bg-indigo-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
                Verified Win
              </div>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">{story.projectTitle}</h2>
            <div className="flex items-center gap-2 mb-4">
               <span className="text-xs font-bold text-indigo-400">{story.hackathonName}</span>
               <span className="w-1 h-1 rounded-full bg-slate-700"></span>
               <span className="text-xs font-bold text-emerald-400">{story.award}</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed mb-8 flex-grow">
              {story.description}
            </p>
            <button className="w-full py-3 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 text-white text-sm font-bold transition-all">
              View Implementation
            </button>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-r from-indigo-900/20 to-transparent p-12 rounded-[3rem] border border-white/5 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-grow space-y-4 text-center md:text-left">
           <h3 className="text-3xl font-bold text-white">Want to see your name here?</h3>
           <p className="text-slate-400">Join over 1,500 developers who use IdeaForge to kickstart their hackathon journey.</p>
        </div>
        <button className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-2xl shadow-indigo-500/20 whitespace-nowrap hover:scale-105 transition-transform">
           Start Ideating Now
        </button>
      </div>
    </div>
  );
};
