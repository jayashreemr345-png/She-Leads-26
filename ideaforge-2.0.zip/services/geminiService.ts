
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, HackathonIdea, Trend } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getTrends = async (): Promise<Trend[]> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: "Identify top 5 current tech trends for hackathons in 2024-2025. Focus on AI, Web3, Sustainability, and HealthTech.",
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            description: { type: Type.STRING },
            source: { type: Type.STRING },
            relevance: { type: Type.NUMBER }
          },
          required: ["topic", "description", "source", "relevance"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse trends", e);
    return [];
  }
};

export const generateHackathonIdea = async (profile: UserProfile): Promise<HackathonIdea> => {
  const prompt = `Generate a high-potential hackathon idea based on these constraints:
    - Skills: ${profile.skills.join(", ")}
    - Interests: ${profile.interests.join(", ")}
    - Experience: ${profile.experienceLevel}
    - Team Size: ${profile.teamSize}
    - Time: ${profile.timeConstraint}
    ${profile.customContext ? `- Additional Context/Requirements: ${profile.customContext}` : ''}
    
    The idea should be novel, technically challenging but feasible within the time limit, and solve a real-world problem. Align the tech stack specifically with the user's skills while adding 1-2 trending technologies.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          problemStatement: { type: Type.STRING },
          solution: { type: Type.STRING },
          techStack: { type: Type.ARRAY, items: { type: Type.STRING } },
          feasibilityScore: { type: Type.NUMBER, description: "Scale 1-10" },
          noveltyScore: { type: Type.NUMBER, description: "Scale 1-10" },
          impactScore: { type: Type.NUMBER, description: "Scale 1-10" },
          winningStrategy: { type: Type.STRING },
          roadmap: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                duration: { type: Type.STRING },
                tasks: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      task: { type: Type.STRING },
                      time: { type: Type.STRING },
                      dependencies: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                  }
                }
              }
            }
          }
        },
        required: ["title", "description", "problemStatement", "solution", "techStack", "feasibilityScore", "noveltyScore", "impactScore", "winningStrategy", "roadmap"]
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}');
  } catch (e) {
    throw new Error("Failed to generate a valid hackathon idea structure.");
  }
};

export const getRelatedIdeas = async (baseIdea: HackathonIdea): Promise<Partial<HackathonIdea>[]> => {
  const prompt = `Based on the project "${baseIdea.title}" which uses ${baseIdea.techStack.join(", ")}, generate 3 distinct but related hackathon project concepts.
  Each concept should be a variation or a logical neighbor in the same domain.
  Return only JSON.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            techStack: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["title", "description", "techStack"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Failed to parse related ideas", e);
    return [];
  }
};
