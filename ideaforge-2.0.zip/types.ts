
export type View = 'home' | 'trends' | 'stories' | 'docs' | 'login';

export interface UserProfile {
  skills: string[];
  interests: string[];
  experienceLevel: 'Beginner' | 'Intermediate' | 'Expert';
  teamSize: number;
  timeConstraint: string;
  customContext: string;
}

export interface RoadmapTask {
  task: string;
  time: string;
  dependencies: string[];
}

export interface RoadmapPhase {
  name: string;
  duration: string;
  tasks: RoadmapTask[];
}

export interface HackathonIdea {
  title: string;
  description: string;
  problemStatement: string;
  solution: string;
  techStack: string[];
  feasibilityScore: number;
  noveltyScore: number;
  impactScore: number;
  winningStrategy: string;
  roadmap: RoadmapPhase[];
}

export interface Trend {
  topic: string;
  description: string;
  source: string;
  relevance: number;
  marketGap?: string;
  difficulty?: string;
}

export interface SuccessStory {
  id: string;
  projectTitle: string;
  hackathonName: string;
  award: string;
  description: string;
  image?: string;
}
